# **KEM租户订购企业套件的下订单网站**


# 0. 更新记录
5. 2020.05.20 将nodered改为devops，增加eureka。
4. 11.26 增加了mongodb,kafka,zookeeper页面,修改了client文件夹的目录结构,将静态文件和配置文件分开,挂载起来更轻松,更新更灵活.
3. 9.03 增加了 nodered 页面.所有访问 kem 接口的参数,首字母大写修改为首字母小写.
2. 9.02 修复了 config 文件夹下 index.js 名字改为 config.js
1. 8.27 第一版
# 1. 项目文件说明
- epc-paas-server.tar：为 2019 年 11 月 26 日,为了方便挂载,更新了配置文件和静态文件的挂载方法.

- sy-paas-server.tar：为跟苏研联调的只有三个页面没有下单按钮的镜像.这一版没有配置文件.
- config文件夹：其中config.js为配置文件示例

# 2. 配置文件说明
- dashboardUrl：KEM的访问路径，例如"http://192.168.18.105:8088/"
- serviceUrl：KEM提供给paas平台接口的地址，一般来说serviceUrl和dashboardUrl是一样的，例如"http://192.168.18.105:8088/"
注意：
(1) KEM地址需要是浏览器能够访问到的地址，如果有内外网IP地址的区分，需要根据环境要求设置为浏览器能够访问的IP
(2) KEM地址URL结尾的“/”必须写上，不能省略

以下参数无需修改：
- serviceName：下单API接口URL
- loginService：用户认证API接口URL
- partitionService：获取租户分区列表的API接口URL

# 3. 启动命令说明
## Master版本
```
docker run -d --name epc-paas-server --restart=always \
    -p 宿主机端口:3000 \
    -e TZ=Asia/Shanghai \
    -v ${PWD}/config:/usr/src/app/client/config/ \
    -v ${PWD}/public:/usr/src/app/client/public/ \
    epc-paas-server
```

## 苏研版本
```
docker run -d --name sy-paas-server -p 宿主机端口:3000  sy-paas-server
```


