/*(function($) {

})(jQuery)
*/
var config = {
  "dashboardUrl":"http://10.255.93.2:1199/",
  "serviceUrl":"http://10.255.93.2:1199/",
  //"dashboardUrl":"http://192.168.18.105:8088/",
  //"serviceUrl":"http://192.168.18.105:8088/",
  
  "serviceName":"Ku8Master/order/creatOrder",
  "loginService":"user/auth",
  "partitionService":"Ku8Master/application/getNamespacesByUser"
}

$.extend({
  dashboardUrl:function(){
    return config.dashboardUrl;
  },
  loginServiceUrl:function(){
    return config.serviceUrl+config.loginService;
  },
  creatOrderUrl:function(){
    return config.serviceUrl+config.serviceName;
  },
  partitionServiceUrl:function(){
    return config.serviceUrl+config.partitionService;
  },
});
