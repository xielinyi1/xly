jQuery(document).ready(function() {
  //判断登录状态
  //跳转控制台
  $(".rgt_btn_ctl").click(function() {
    var username = localStorage.getItem("username");

    if (username) {
      //go to control center;
      location.href = "";
    } else {
      //go to login page;
      location.href = "./login";
    }
  });
});
