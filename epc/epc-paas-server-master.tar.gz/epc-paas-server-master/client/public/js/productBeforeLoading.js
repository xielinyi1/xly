jQuery(document).ready(function($) {

    var lastLogin = localStorage.getItem("loginTime");
    
    var now = Date.now();
    if(lastLogin === "" || lastLogin === undefined || lastLogin === null ||lastLogin.length !=13 || parseInt(now)-parseInt(lastLogin)>1800000){
        
        window.location.href = './login.html'
    }
})