var myTools;
(function($) {

	 myTools = {		
			BASE_URL : "http://localhost:9999",
/**
 		options = {
 			"async" : 是否异步请求，默认false
 			"url" : 服务端请求地址，不包含BASE_URL
			"action" : 动作标识
 			"params" : 动作对应的参数
 			"success" : 请求成功后的回调，参数(resultData, xhr)
 			"error" : 请求失败后的回调，参数(msg, xhr)
 		}
 */

		sendOrder : function(options) {
				
				var self = this; 
				var data = self.generateOrderData(options);
				url = $.creatOrderUrl();
				singleRequest=$.ajax({
					"type" : options.type||"post" ,
					"async" : options.async ? options.async : false,
					"dataType" : "json",
					"url" : url,
					"timeout" : options.timeout ? options.timeout : 30000,
					"data" :  data,
					"complete" : function(xhr) {

						if (xhr.readyState == 4 && xhr.status == 200) {

							if (options.success) {
								options.success.call(this, xhr.responseJSON);
					
							};
						} else {
							alert("下单失败")
						}
						return false;
					}

				});
			},
		random : function(len,radix){
				var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split("");
				var uuid = [],i;
				radix = radix || chars.length;
				for(i=0;i<len;i++){
					uuid[i] = chars[0 | Math.random()*radix];

				}
				return uuid.join("");
		},
		timeStamp : function(){
				let date = new Date();
				var Y = date.getFullYear();
				var M = (date.getMonth() +1 <10 ? "0"+(date.getMonth() +1):(date.getMonth() +1));
				var D = (date.getDate()<10? "0"+date.getDate():date.getDate());
				var h = (date.getHours()<10? "0"+date.getHours():date.getHours());
				var m = (date.getMinutes()<10? "0"+date.getMinutes():date.getMinutes());
				var s = (date.getSeconds()<10? "0"+date.getSeconds():date.getSeconds());
				let time = Y+M+D+h+m+s;
				return time;
			},
		generateOrderData : function(options){
			var token = localStorage.getItem("token");
			var userName = localStorage.getItem("username");
			var orderName = options.name;
			let transID = this.random(32,10);
				let oprType = options.oprType;
				let orderID = this.random(20,10);
				let pOrderID = this.random(20,10);
				let userID = this.random(6,10);
				let myUserName = userName;
				let products = [{productType:"01",productConf:options._json,productID:"P050101001"}];
				let oprTime = this.timeStamp();
				var __json = {
					transID:transID,
					oprType:oprType,
					orderID:orderID,
					pOrderID:pOrderID,
					userID:userID,
					userName:myUserName,
					products:products,
					oprTime:oprTime

				}
			var data = {
				token: token,
				name: orderName,
				userName: userName,
				json: JSON.stringify(__json)
			}
			
			return data;
		}
			
		};
})(jQuery);
