const express = require("express");
const pageRouter = require("./router/router");
const path = require('path');
const app = express();
const methods = ["get", "post", "put", "delete"];
const router = new express.Router();
app.use(router);

for (let method of methods) {
  app[method] = function (...data) {
    if (method === "get" && data.length === 1) return app.set(data[0]);

    const params = [];
    for (let item of data) {
      if (Object.prototype.toString.call(item) !== "[object AsyncFunction]") {
        params.push(item);
        continue;
      }
      const handle = function (...data) {
        const [req, res, next] = data;
        item(req, res, next)
          .then(next)
          .catch(next);
      };
      params.push(handle);
    }
    router[method](...params);
  };
}
// view engine setup
app.set('views', path.join(__dirname, 'client/public'));
//注册ejs模板为html页。简单的讲，就是原来以.ejs为后缀的模板页，现在的后缀名可以//是.html了
app.engine('.html', require('ejs').__express);
//设置视图模板的默认后缀名为.html,避免了每次res.Render("xx.html")的尴尬
app.set('view engine', 'html');
app.use(express.static(path.join(__dirname, 'client/config')));
app.use(express.static(path.join(__dirname, 'client/public')));
//app.use("/", pageRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error("Not Found");
  err.status = 404;
  next(err);
});

app.use(function (err, req, res, next) {
  res.status(500).send({
    message: err.message,
    error: err
  });
});
app.listen(3000, function () {
  console.log('listening on port 3000');
});