const express = require('express');
const router = express.Router();
/* GET home page. */
router.get('/product/', function(req, res, next) {
    console.log("getting request from :"+req.ip);
    let productID =req.query.ProductID;
    switch(productID) {
        case 'P010201001':
        res.render('mysqlDocker.html');
        break;
        case 'P010201002':  
        res.render('mysqlVirtual.html');
        break;
        case 'P010101001':  
        res.render('elasticCompute.html');
        break;
        default:
        var err = new Error("Page Not Found");
        err.status = 404;
        next(err);
        break;
      }
    
  
});


module.exports = router;